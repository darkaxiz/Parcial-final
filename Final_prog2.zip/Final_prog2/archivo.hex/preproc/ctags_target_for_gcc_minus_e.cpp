# 1 "C:\\Users\\Personal1\\Desktop\\Documentos\\2019\\Leanguaje de Programacion 2\\Final\\sketch_jul26b\\sketch_jul26b.ino"
# 1 "C:\\Users\\Personal1\\Desktop\\Documentos\\2019\\Leanguaje de Programacion 2\\Final\\sketch_jul26b\\sketch_jul26b.ino"
uint16_t const cabecera="EFFE";
char estado="A",s[17];
float s1, s2, s3, tempC, tempC1, tempC2, mv, mv1, mv2, V, V1, V2;
int in1=0, in2=A1, in3=A2;
unsigned char *dato;
unsigned long fa;

int condicion=0;
struct trama
{
  uint16_t header;
  char state;
  float vol1;
  float vol2;
  float vol3;
  uint8_t otros;
  uint8_t cheksum;
};
struct trama trama2;
uint8_t XORChecksum8(void* data, unsigned char n)
{
  uint16_t cont=0;
  unsigned char* p=data;
  unsigned char i;
  cont=p[0];
  for (i=0;i<n-1;i++)
  {
   cont=cont^p[i+1];
  }
  return(cont);
}
void setup() {
    Serial.begin(9600);
}
void loop() {
  //LECTURA SENSORES
  tempC = analogRead(in1);
  tempC1 = analogRead(in2);
  tempC2 = analogRead(in3);
  //CONVERSION A VOLATAJE

  V =(tempC*5)/1023;
  V1=(tempC1*5)/1023;
  V2 =(tempC2*5)/1023;

  //VALORES TRAMA
  trama2.header=0XFEEF;
  trama2.state=0X41;
  trama2.vol1=V;
  trama2.vol2=V1;
  trama2.vol3=V2;
  trama2.otros=0.0;
  dato = (unsigned char*)(&trama2);
  int x=sizeof(trama2);
  trama2.cheksum=XORChecksum8(&trama2.state,sizeof(trama2)-3);
  for (int i=0; i<x; i++)
  {
   fa=*(dato+i);
   sprintf(s ,"%02x",fa);
   Serial.print(s);
  }
  delay(1000);
  Serial.println();
}
